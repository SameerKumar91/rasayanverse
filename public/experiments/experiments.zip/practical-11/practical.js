/* RasayanVerse Practical 11 — Carbonate Ion Test
   Verified interaction engine: step-by-step controls, sample selection,
   virtual-lab progress, observation/result updates, reset and quiz.
*/
document.addEventListener("DOMContentLoaded", () => {
    "use strict";

    const steps = [{"title": "Prepare sample", "text": "Click Prepare Sample."}, {"title": "Add acid", "text": "Click Add Dilute HCl and observe bubbles."}, {"title": "Collect gas", "text": "Click Pass Gas to Limewater."}, {"title": "Observe limewater", "text": "The limewater becomes milky when CO₂ is confirmed."}, {"title": "Record result", "text": "Record the carbonate inference."}];
    const config = {"required": false, "scene": "carbonate", "complete": "Carbonate produced carbon dioxide with acid; the gas turned limewater milky.", "fixed": ["Acid + carbonate", "Effervescence", "CO₂", "Limewater milky", "Completed"]};

    let current = 1;
    let selected = null;
    let done = false;
    let busy = false;

    const qs = (s) => document.querySelector(s);
    const buttons = [...document.querySelectorAll(".lab-action-button")];
    const sampleButtons = [...document.querySelectorAll(".sample-choice")];

    const instructionTitle = qs("#instructionTitle");
    const instructionText = qs("#instructionText");
    const progress = qs("#instructionProgress");
    const count = qs("#instructionCount");
    const status = qs("#labStatus");
    const reading = qs("#readingValue");
    const colour = qs("#colourValue");
    const endpoint = qs("#endpointValue");
    const indicator = qs("#endpointIndicator");
    const resultHeading = qs("#resultHeading");
    const resultText = qs("#resultText");
    const reset = qs("#resetExperiment");
    const quizSubmit = qs("#quizSubmit");
    const quizResult = qs("#quizResult");
    const sceneEl = qs(".concept-lab-scene");

    function setText(el, value) {
        if (el) el.textContent = value;
    }

    function observationValues() {
        if (config.values && selected && config.values[selected]) return config.values[selected];
        return config.fixed || ["Complete","—","—","—","Recorded"];
    }

    function updateObservation() {
        const cells = [...document.querySelectorAll('[id^="obs"]')];
        const vals = observationValues();
        cells.forEach((cell, index) => setText(cell, vals[index] ?? "—"));
    }

    function updateVisual() {
        if (!sceneEl) return;
        sceneEl.classList.remove(...Array.from({length: 6}, (_,i) => `progress-${i+1}`));
        sceneEl.classList.add(`progress-${Math.min(current, 5)}`);
        if (done) sceneEl.classList.add("completed");
    }

    function requiredSelectionMissing() {
        if (!config.required) return false;
        if (current !== 1) return false;
        return !selected;
    }

    function selectionRequiredAtCurrentStep() {
        if (config.selection_at && current === config.selection_at) return !selected;
        return requiredSelectionMissing();
    }

    function update() {
        const step = steps[current - 1] || steps[steps.length - 1];
        setText(instructionTitle, step.title);
        setText(instructionText, step.text);
        setText(count, `Step ${Math.min(current, steps.length)} of ${steps.length}`);
        if (progress) progress.style.width = `${(Math.min(current, steps.length) / steps.length) * 100}%`;
        setText(reading, `${Math.min(current, steps.length)} / ${steps.length}`);

        buttons.forEach((button, index) => {
            const isCurrent = index === current - 1;
            button.disabled = done || busy || !isCurrent;
        });

        if (selectionRequiredAtCurrentStep() && buttons[0]) buttons[0].disabled = false;

        updateVisual();
        updateObservation();
    }

    function selectSample(button) {
        selected = button.dataset.sample || button.textContent.trim();
        sampleButtons.forEach((b) => b.classList.toggle("selected", b === button));
        setText(colour, selected);
        setText(status, "Selection recorded");
        update();
    }

    sampleButtons.forEach((button) => {
        button.addEventListener("click", () => selectSample(button));
    });

    function performStep() {
        if (done || busy) return;

        if (selectionRequiredAtCurrentStep()) {
            setText(status, "Choose an option first");
            sampleButtons[0]?.focus();
            return;
        }

        const button = buttons[current - 1];
        if (!button) return;

        busy = true;
        button.classList.add("working");
        setText(status, "Performing…");

        if (sceneEl) sceneEl.classList.add(`progress-${current}`);

        window.setTimeout(() => {
            button.classList.remove("working");
            busy = false;

            if (current < steps.length) {
                current += 1;
                setText(status, "Step completed");
                setText(endpoint, current === steps.length ? "Final action ready" : "In progress");
                if (current === steps.length && indicator) {
                    indicator.innerHTML = "<span></span> Final action ready.";
                }
                update();
                return;
            }

            done = true;
            current = steps.length;
            buttons.forEach((b) => b.disabled = true);
            setText(status, "Practical completed");
            setText(endpoint, "Completed");

            if (indicator) {
                indicator.classList.add("reached");
                indicator.innerHTML = "<span></span> Practical completed successfully.";
            }

            const vals = observationValues();
            setText(colour, vals[1] || selected || "Observation recorded");
            setText(resultHeading, "Practical completed successfully.");
            setText(resultText, config.complete);
            updateObservation();
            updateVisual();
        }, 500);
    }

    buttons.forEach((button) => button.addEventListener("click", performStep));

    if (reset) reset.addEventListener("click", () => window.location.reload());

    if (quizSubmit && quizResult) {
        quizSubmit.addEventListener("click", () => {
            const answers = { q1: "a", q2: "a", q3: "a" };
            let score = 0;

            Object.entries(answers).forEach(([question, answer]) => {
                const selectedAnswer = document.querySelector(`input[name="${question}"]:checked`);
                if (selectedAnswer && selectedAnswer.value === answer) score += 1;
            });

            const message =
                score === 3
                    ? "Excellent! You understand this practical very well. 🎉"
                    : score === 2
                        ? "Good work! Review the procedure once more."
                        : "Keep learning! Review the concept and try the quiz again.";

            quizResult.innerHTML = `Score: <strong>${score}/3</strong><br>${message}`;
            quizResult.classList.add("show");
        });
    }

    update();
});
